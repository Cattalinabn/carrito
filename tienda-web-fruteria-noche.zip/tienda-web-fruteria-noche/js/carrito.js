//seleccionar todos los botones añadir
//al carrito
const d = document;
let btnCarrito = d.querySelectorAll(".boton-carrito");
//selecionar la tabla de los productos del carrito
let tablaCarrito = d.querySelector(".listado-producto tbody");
//seleccionar la bolsa del menu
let bolsa = d.querySelector(".bolsa");
let contadorPro = 0;
let productosLocal = "productos";

for( let x=0; x < btnCarrito.length; x++ ){
    btnCarrito[x].setAttribute("id", x);
    let btnId = btnCarrito[x].getAttribute("id");
    btnCarrito[x].addEventListener("click", function(){
        //alert("di click "+btnId);
        alertaPro();
        //ejecutar la funcion para obtener la informacion
        infoPro( btnId );
    });
}
//console.log(btnCarrito);
//funcion para contar cuantos productos añado a la bolsa
function alertaPro() {
    contadorPro++;
    bolsa.textContent = contadorPro;
}

//obtener la informaion del producto
function infoPro( idBoton ) {
    let producto;
    if( btnCarrito[idBoton].classList.contains("boton-carrito") ){
        producto = btnCarrito[idBoton].parentElement.parentElement.parentElement;
        console.log(producto);
    }
    let informacionPro = {
        "id": idBoton,
        "nombre": producto.querySelector(".titulo-pro").textContent,
        "precio": producto.querySelector(".precio-normal").textContent,
        "imagen": producto.querySelector(".con-imagen img").src
    }
    console.log( informacionPro );
    AgregarAlcarrito(informacionPro);
    GuardarEnLocal(informacionPro);
}

//agregar productos al carrito
let contarCart = 0
function AgregarAlcarrito(informacionProducto) {
    let fila = document.createElement("tr");
    contarCart++
    fila.innerHTML = ` 
    <td> ${contarCart} </td>
    <td> <img src =" ${ informacionProducto.imagen}" width ="50%" > </td>
    <td> ${informacionProducto.nombre} </td>
    <td> ${informacionProducto.precio} </td>
    <td> 
        <span class = "text-danger"> X </span>    
    </td>
    `;
    tablaCarrito.appendChild(fila)
}

//guardar productos en localStorage
function GuardarEnLocal(objectPro) {
    let productos = [];
    let productosGuardados = JSON.parse( localStorage.getItem(productosLocal));
    if (productosGuardados !== null) {
        productos = productosGuardados;
    }
    productos.push(objectPro);
    localStorage.setItem(productosLocal, JSON.stringify(productos))
    console.log(productos);
}